package com.gemini.guard

import android.app.Activity
import android.app.AlertDialog
import android.view.Gravity
import android.widget.ImageView
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private val BG = 0xFFF1F3F8.toInt()
private val CARD = Color.WHITE
private val INK = 0xFF1B1D22.toInt()
private val MUTED = 0xFF6B7280.toInt()
private val ACCENT = 0xFF3B6FE0.toInt()
private val TONAL = 0xFFE6EDFC.toInt()
private val GOOD = 0xFF1E8E3E.toInt()
private val BAD = 0xFFC62828.toInt()
private val FIELD = 0xFFF4F5F9.toInt()
private val LINE = 0xFFD9DCE5.toInt()

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var ctsPkg: EditText
    private lateinit var miPkgs: EditText
    private lateinit var miInc: EditText
    private lateinit var miExc: EditText
    private lateinit var trPkg: EditText
    private lateinit var trTxt: EditText
    private lateinit var sndCls: EditText
    private lateinit var warnCard: LinearLayout
    private lateinit var stateBox: LinearLayout
    private lateinit var shzCmd: EditText
    private lateinit var shzOut: TextView

    private fun prefs() = Restorer.prefs(this)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun pushService() {
        Restorer.ensure(this)
        if (prefs().getBoolean("enabled", true) || prefs().getBoolean("bar", false))
            startForegroundService(Intent(this, GuardService::class.java))
        else stopService(Intent(this, GuardService::class.java))
    }

    // ---------- Hỗ trợ ----------
    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, L.tr("Không mở được liên kết: ") + e.message, Toast.LENGTH_LONG).show() }
    }

    /** Luu anh QR vao thu vien (Pictures/GeminiGuard) de quet bang ung dung ngan hang tren cung dien thoai. */
    private fun saveQr() {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) {
                Toast.makeText(this, L.tr("Android thấp: hãy chụp màn hình mã QR rồi quét từ thư viện"), Toast.LENGTH_LONG).show(); return
            }
            val bmp = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.qr_donate)
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "GeminiGuard_QR_mi_tom.png")
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/GeminiGuard")
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException(L.tr("không tạo được tệp"))
            contentResolver.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, L.tr("Đã lưu ảnh QR vào thư viện (Pictures/GeminiGuard)"), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, L.tr("Không lưu được ảnh: ") + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun showSupport() {
        val url = "https://www.facebook.com/datbeans512/"
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        body.addView(label(L.tr("Cần hỗ trợ cài đặt hoặc gặp lỗi? Liên hệ admin Gemini Guard qua Facebook để được trợ giúp."), 14f, INK))
        body.addView(label("Facebook admin", 13f, MUTED, true).apply { setPadding(0, dp(14), 0, 0) })
        body.addView(TextView(this).apply {
            text = url; textSize = 14f; setTextColor(ACCENT)
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            setPadding(0, dp(4), 0, dp(4))
            setOnClickListener { openUrl(url) }
        })
        body.addView(label(
            L.tr("Khi nhờ hỗ trợ, bạn nên gửi kèm ảnh chụp màn hình và nút \"Sao chép trạng thái\" ") +
                L.tr("(mục Công cụ và chẩn đoán)."),
            12f, MUTED).apply { setPadding(0, dp(12), 0, 0) })

        // Ung ho admin
        body.addView(View(this).apply { setBackgroundColor(0x1F000000) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(18) })
        body.addView(label(L.tr("Hỗ trợ admin gói mì tôm"), 16f, INK, true).apply { setPadding(0, dp(16), 0, 0) })
        body.addView(label(L.tr("Nếu thấy app hữu ích, bạn có thể mời admin một gói mì tôm bằng cách quét mã QR bên dưới (mọi ứng dụng ngân hàng và ví đều quét được). Không bắt buộc nhé."), 13f, MUTED)
            .apply { setPadding(0, dp(6), 0, dp(10)) })
        body.addView(ImageView(this).apply {
            setImageResource(R.drawable.qr_donate)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        btn(body, L.tr("Lưu ảnh QR vào thư viện"), top = 8) { saveQr() }
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(8)))

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
            .setTitle(L.tr("Hỗ trợ"))
            .setView(ScrollView(this).apply { addView(body) })
            .setPositiveButton(L.tr("Mở Facebook")) { _, _ -> openUrl(url) }
            .setNeutralButton(L.tr("Sao chép link")) { _, _ -> copy("facebook", url, L.tr("Đã sao chép liên kết")) }
            .setNegativeButton(L.tr("Đóng"), null)
            .show()
    }

    // ---------- Thành phần giao diện ----------
    private fun shape(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun card(root: LinearLayout, title: String, desc: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 18)
            setPadding(dp(18), dp(16), dp(18), dp(18))
            elevation = dp(1).toFloat()
        }
        c.addView(label(title, 17f, INK, true))
        if (desc != null) c.addView(label(desc, 13f, MUTED).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(c, lp(14))
        return c
    }

    private fun sw(p: LinearLayout, text: String, hint: String?, key: String, def: Boolean) {
        val s = Switch(this).apply {
            this.text = text; textSize = 15f; setTextColor(INK)
            isChecked = prefs().getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs().edit().putBoolean(key, on).apply(); pushService() }
        }
        p.addView(s, lp(14))
        if (hint != null) p.addView(label(hint, 12f, MUTED).apply { setPadding(0, dp(2), 0, 0) }, lp(0))
    }

    /** Chon ngon ngu giao dien: tu dong / English / Tieng Viet. */
    private fun langRow(p: LinearLayout) {
        val opts = listOf("auto" to "Auto / Tự động", "en" to "English", "vi" to "Tiếng Việt")
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label("Language / Ngôn ngữ", 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val cur = prefs().getString("lang", "auto") ?: "auto"
        row.addView(label(opts.firstOrNull { it.first == cur }?.second ?: opts[0].second, 14f, ACCENT, true))
        row.setOnClickListener {
            val idx = opts.indexOfFirst { it.first == cur }.coerceAtLeast(0)
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle("Language / Ngôn ngữ")
                .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), idx) { d, which ->
                    prefs().edit().putString("lang", opts[which].first).apply()
                    L.load(this)
                    d.dismiss()
                    recreate()
                }
                .setNegativeButton("Cancel / Hủy", null)
                .show()
        }
        p.addView(row)
    }

    /** Dong chon 1 trong nhieu lua chon (hop thoai), dung chung cho moi noi can "picker". */
    private fun pickRow(p: LinearLayout, text: String, key: String, opts: List<Pair<String, String>>, default: String, onChange: (() -> Unit)? = null) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun labelOf(v: String) = opts.firstOrNull { it.first == v }?.second ?: v
        val cur = prefs().getString(key, default) ?: default
        val value = label(labelOf(cur), 14f, ACCENT, true)
        row.addView(value)
        row.setOnClickListener {
            val now = prefs().getString(key, default) ?: default
            val idx = opts.indexOfFirst { it.first == now }.coerceAtLeast(0)
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle(text)
                .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), idx) { d, which ->
                    prefs().edit().putString(key, opts[which].first).apply()
                    value.text = opts[which].second
                    d.dismiss()
                    onChange?.invoke()
                    refresh()
                }
                .setNegativeButton(L.tr("Hủy"), null)
                .show()
        }
        p.addView(row)
    }

    /** Dong chon hanh dong cho cu chi (hop thoai chon 1). */
    private fun choice(p: LinearLayout, text: String, key: String) {
        val opts = BarOverlay.ACTIONS
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun labelOf(v: String) = L.tr(opts.firstOrNull { it.first == v }?.second ?: v)
        val value = label(labelOf(BarOverlay.currentAction(prefs(), key)), 14f, ACCENT, true)
        row.addView(value)
        row.setOnClickListener {
            val cur = BarOverlay.currentAction(prefs(), key)
            val idx = opts.indexOfFirst { it.first == cur }.coerceAtLeast(0)
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle(text)
                .setSingleChoiceItems(opts.map { L.tr(it.second) }.toTypedArray(), idx) { d, which ->
                    prefs().edit().putString(key, opts[which].first).apply()
                    value.text = L.tr(opts[which].second)
                    d.dismiss()
                }
                .setNegativeButton(L.tr("Hủy"), null)
                .show()
        }
        p.addView(row)
    }

    private fun seek(p: LinearLayout, text: String, unit: String, key: String, max: Int, def: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = label("${prefs().getInt(key, def)}$unit", 14f, ACCENT, true)
        row.addView(v)
        p.addView(row, lp(16))
        val sb = SeekBar(this).apply {
            this.max = max; progress = prefs().getInt(key, def)
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) { v.text = "$pr$unit" }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {
                    prefs().edit().putInt(key, s.progress).apply(); pushService()
                }
            })
        }
        p.addView(sb, lp(0))
    }

    private fun btn(p: LinearLayout, text: String, primary: Boolean = false, top: Int = 12, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text; isAllCaps = false; textSize = 14f
            setTextColor(if (primary) Color.WHITE else ACCENT)
            stateListAnimator = null; minimumHeight = dp(46)
            background = RippleDrawable(
                ColorStateList.valueOf(0x33000000),
                shape(if (primary) ACCENT else TONAL, 12), shape(Color.WHITE, 12)
            )
            setOnClickListener { action(); refresh() }
        }
        p.addView(b, lp(top))
    }

    private fun field(p: LinearLayout, title: String, hint: String, value: String): EditText {
        p.addView(label(title, 12f, MUTED), lp(16))
        val e = EditText(this).apply {
            this.hint = hint; setText(value); textSize = 14f; setTextColor(INK)
            setSingleLine(true)
            background = shape(FIELD, 12, LINE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        p.addView(e, lp(6))
        return e
    }

    private fun stateRow(ok: Boolean, name: String, okText: String, badText: String): TextView {
        val color = if (ok) GOOD else BAD
        val sb = SpannableStringBuilder("●  ")
        sb.setSpan(ForegroundColorSpan(color), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append(name).append(":  ")
        val start = sb.length
        sb.append(if (ok) okText else badText)
        sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return TextView(this).apply { text = sb; textSize = 14f; setTextColor(INK); setPadding(0, dp(3), 0, dp(3)) }
    }

    private fun copy(name: String, value: CharSequence, toast: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(name, value))
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show()
    }

    private fun openAppSettings() =
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))

    private fun bindPref(e: EditText, key: String) {
        e.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                prefs().edit().putString(key, s?.toString()?.trim() ?: "").apply()
            }
        })
    }

    private fun learnMode(mode: String) {
        prefs().edit().putString("learn_mode", mode)
            .putLong("learn_until", android.os.SystemClock.elapsedRealtime() + 20000L).apply()
        Toast.makeText(this,
            if (mode == "inc") L.tr("Hãy gọi Mi AI bằng giọng nói ngay (trong 20 giây), chỉ cần nói câu gọi.")
            else L.tr("Hãy mở app Mi AI và bật dịch màn hình ngay (trong 20 giây)."),
            Toast.LENGTH_LONG).show()
    }

    private fun openAutostart() {
        try {
            startActivity(Intent().setComponent(ComponentName(
                "com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")))
        } catch (_: Exception) {
            openAppSettings()
            Toast.makeText(this, L.tr("Tìm Tự khởi động / Autostart rồi bật Gemini Guard."), Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Màn hình chính ----------
    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs().edit().remove("evlog").remove("ev_log").apply()   // don nhat ky su kien cu (tinh nang da go)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        window.statusBarColor = BG
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(22), dp(16), dp(36))
        }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }

        // Tiêu đề
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
        }
        head.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(10) })
        head.addView(label("Gemini Guard", 26f, INK, true))
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        head.addView(TextView(this).apply {
            text = L.tr("Hỗ trợ"); textSize = 14f; setTextColor(ACCENT); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = shape(TONAL, 20)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { showSupport() }
        })
        root.addView(head, lp(0))
        root.addView(label(L.fmt("Giữ Gemini luôn là trợ lý mặc định · phiên bản %s", ver), 13f, MUTED), lp(2))

        // Cảnh báo thiếu quyền
        warnCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0xFFFDECEA.toInt(), 18, 0xFFF3B9B3.toInt())
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        warnCard.addView(label(L.tr("Chưa cấp quyền ghi cài đặt bảo mật"), 16f, BAD, true))
        warnCard.addView(label(
            L.tr("Thiếu quyền WRITE_SECURE_SETTINGS nên app không giữ được Google làm trợ lý ") +
                L.tr("(máy sẽ hiện bảng “Complete action using” và mở app Google). Hãy cấp bằng ADB. ") +
                L.tr("Khi cập nhật, cài đè lên bản cũ và đừng gỡ cài đặt, vì gỡ sẽ mất quyền."),
            13f, INK).apply { setPadding(0, dp(6), 0, 0) })
        btn(warnCard, L.tr("Tự cấp quyền qua Shizuku (không cần máy tính)"), primary = true) { grantViaShizuku() }
        btn(warnCard, L.tr("Sao chép lệnh ADB cấp quyền"), top = 8) {
            copy("adb", "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS", L.tr("Đã sao chép lệnh ADB"))
        }
        root.addView(warnCard, lp(14))

        // Trạng thái nhanh
        val st = card(root, L.tr("Trạng thái"))
        stateBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        st.addView(stateBox, lp(8))

        // 1. Giữ Gemini
        val c1 = card(root, L.tr("Giữ Gemini làm trợ lý"),
            L.tr("Canh các cài đặt hệ thống, nếu HyperOS xóa hoặc đổi sang Mi AI thì tự ghi lại trợ lý đã chọn bên dưới."))
        pickRow(c1, L.tr("Trợ lý mục tiêu"), "target_pkg",
            listOf(Restorer.GOOGLE_PKG to "Gemini (Google)", Restorer.CHATGPT_PKG to "ChatGPT"), Restorer.GOOGLE_PKG) {
            val ch = Restorer.ensure(this)
            Toast.makeText(this,
                if (ch.isEmpty()) L.tr("Mọi thứ đã đúng")
                else L.fmt("Đã chuyển sang %s · đã sửa %d mục", Restorer.targetLabel(this), ch.size),
                Toast.LENGTH_LONG).show()
        }
        sw(c1, L.tr("Canh nền và tự khôi phục Google"), null, "enabled", true)
        btn(c1, L.tr("Khôi phục ngay"), primary = true) {
            val ch = Restorer.ensure(this)
            Toast.makeText(this, if (ch.isEmpty()) L.tr("Mọi thứ đã đúng") else L.fmt("Đã sửa %d mục", ch.size), Toast.LENGTH_SHORT).show()
        }

        btn(c1, L.tr("Khởi động lại trợ lý (tắt → bật)"), top = 8) {
            Toast.makeText(this, L.tr("Đang tắt → bật lại, giữ app mở vài giây…"), Toast.LENGTH_SHORT).show()
            Thread {
                val res = Restorer.cycle(this)
                runOnUiThread { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); refresh() }
            }.start()
        }
        sw(c1, L.tr("Tự tắt → bật lại Google sau khi khởi động máy"),
            L.tr("Để giữ nút nguồn gọi Google thay vì Mi AI sau mỗi lần khởi động. Cần bật Tự khởi động cho app."),
            "cycle_boot", true)
        seek(c1, L.tr("Đợi sau khi máy khởi động xong"), L.tr(" giây"), "cycle_boot_delay_s", 30, 0)
        btn(c1, L.tr("Cho phép tự khởi động trên HyperOS"), top = 8) { openAutostart() }

        // 2. Thanh điều hướng AI
        val c2 = card(root, L.tr("Thanh điều hướng AI"),
            L.tr("Thanh nhỏ nổi ở đáy màn hình. Chọn việc cho từng cử chỉ bên dưới."))
        sw(c2, L.tr("Bật thanh điều hướng AI"), null, "bar", false)
        btn(c2, L.tr("Cấp quyền hiển thị trên ứng dụng khác")) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        ctsPkg = field(c2, L.tr("Tên gói MiCTS"), "com.parallelc.micts", prefs().getString("cts_pkg", "com.parallelc.micts") ?: "")
        choice(c2, L.tr("Chạm đúp"), "bar_dt")
        choice(c2, L.tr("Giữ"), "bar_lp")
        trPkg = field(c2, L.tr("Dịch màn hình: tên gói app dịch"), "com.xiaomi.aiasst.vision", prefs().getString("tr_pkg", BarOverlay.TR_PKG) ?: "")
        bindPref(trPkg, "tr_pkg")
        trTxt = field(c2, L.tr("Dịch màn hình: chữ trên thẻ (phân cách bằng dấu phẩy)"), BarOverlay.TR_TEXT, prefs().getString("tr_text", BarOverlay.TR_TEXT) ?: "")
        bindPref(trTxt, "tr_text")
        seek(c2, L.tr("Chiều rộng"), "%", "bar_w", 100, 40)
        seek(c2, L.tr("Chiều cao"), " dp", "bar_h", 60, 20)
        seek(c2, L.tr("Cách đáy"), " dp", "bar_y", 60, 0)
        seek(c2, L.tr("Độ đậm (0 = vô hình)"), "%", "bar_a", 100, 30)

        // 3. Mi AI
        val c3 = card(root, L.tr("Gọi Gemini khi Mi AI bật lên") + L.tr(" (không dùng được ngân hàng và VNeID, muốn dùng phải tắt đi)"),
            L.tr("Khi phát hiện Mi AI (giữ nút nguồn, gọi giọng nói…), app đóng nó (bấm Back và chạm vào chỗ trống) rồi gọi Gemini lên thay thế. Cần bật Trợ năng cho Gemini Guard – nhiều app ngân hàng và VNeID sẽ chặn hoặc cảnh báo khi Trợ năng đang bật, nên tắt mục này (và tắt Trợ năng) trước khi dùng các app đó."))
        sw(c3, L.tr("Tự gọi Gemini khi Mi AI bật lên"), null, "mi_on", false)
        seek(c3, L.tr("Vị trí chạm – ngang"), "%", "mi_tx", 100, 8)
        seek(c3, L.tr("Vị trí chạm – dọc"), "%", "mi_ty", 100, 10)
        seek(c3, L.tr("Chờ trước khi chạm đóng Mi AI (0 = nhanh nhất)"), " ms", "mi_tapwait", 400, 0)
        seek(c3, L.tr("Độ trễ trước khi gọi Gemini"), " ms", "mi_delay", 1500, 350)
        miPkgs = field(c3, L.tr("Tên gói Mi AI (cách nhau bằng dấu phẩy)"), "com.miui.voiceassist",
            prefs().getString("mi_pkgs", MiAiWatcher.DEFAULT_PKGS) ?: "")
        miInc = field(c3, L.tr("Chỉ gọi Gemini khi cửa sổ Mi AI là (để trống = mọi cửa sổ)"), L.tr("Để trống = mọi cửa sổ"), prefs().getString("mi_inc", MiAiWatcher.DEFAULT_INC) ?: "")
        bindPref(miInc, "mi_inc")
        miExc = field(c3, L.tr("Bỏ qua khi cửa sổ Mi AI là (mở app, dịch màn hình…)"), L.tr("Để trống = không bỏ qua cửa sổ nào"), prefs().getString("mi_exc", MiAiWatcher.DEFAULT_EXC) ?: "")
        bindPref(miExc, "mi_exc")
        btn(c3, L.tr("Đặt lại bộ lọc về mặc định"), top = 12) {
            prefs().edit().remove("mi_inc").remove("mi_exc").remove("learn_mode").apply()
            refresh()
        }
        btn(c3, L.tr("Mở cài đặt Trợ năng"), primary = true) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(c3, L.tr("Cho phép cài đặt bị hạn chế (Android 13+)"), top = 8) { openAppSettings() }

        // 4. Âm thanh
        val c4 = card(root, L.tr("Hiệu ứng âm thanh và rung"),
            L.tr("Phát âm thanh / rung nhẹ khi Gemini hiện lên: giữ nút nguồn, gọi giọng nói (qua Mi AI) hoặc dùng thanh. Cần bật Trợ năng để nhận ra khi giữ nút nguồn."))
        sw(c4, L.tr("Phát âm thanh khi Gemini hiện lên"), null, "snd_on", false)
        seek(c4, L.tr("Âm lượng hiệu ứng"), "%", "snd_vol", 100, 100)
        seek(c4, L.tr("Khuếch đại thêm (0 = tắt)"), " dB", "snd_gain", 15, 0)
        seek(c4, L.tr("Bỏ qua đầu âm thanh để bớt trễ"), " ms", "snd_skip", 600, 0)
        seek(c4, L.tr("Chống lặp âm thanh"), L.tr(" giây"), "snd_gap_s", 10, 3)
        sndCls = field(c4, L.tr("Lọc tên cửa sổ Google (tùy chọn)"), L.tr("Để trống = mọi cửa sổ"), prefs().getString("snd_cls", "") ?: "")
        btn(c4, L.tr("Thử âm thanh"), primary = true) { GeminiSound.play(this, force = true) }
        sw(c4, L.tr("Rung nhẹ khi Gemini hiện lên"), L.tr("Máy rung ngắn tạo cảm giác cửa sổ bật ra. Dùng chung bộ lọc cửa sổ và chống lặp với âm thanh ở trên."), "vib_on", false)
        seek(c4, L.tr("Độ mạnh rung"), "%", "vib_str", 100, 60)
        seek(c4, L.tr("Thời gian rung"), " ms", "vib_ms", 80, 25)
        btn(c4, L.tr("Thử rung"), top = 8) { Haptic.pop(this, force = true) }

        // 5. Công cụ
        val ct = card(root, L.tr("Gọi giọng nói AI và dịch màn hình (không cần quyền Trợ năng – vẫn dùng được VNeID và ngân hàng, nhưng hiệu ứng không được tốt)"),
            L.tr("Thử phát hiện Mi AI và gọi Gemini mà KHÔNG bật dịch vụ Trợ năng, để tránh bị app ngân hàng / ví điện tử cảnh báo \"rủi ro mất tiền\". Dùng quyền \"Truy cập sử dụng\" để biết app nào vừa lên nền trước, thay cho Trợ năng. Vì không có Trợ năng nên app không bấm Back hay chạm màn hình được, chỉ thử tắt tiến trình Mi AI rồi gọi Gemini chồng lên – CÓ THỂ không đóng được Mi AI, hãy bấm \"Thử ngay\" để kiểm tra trước khi tin dùng."))
        ct.addView(label(L.tr("Đây là tính năng thử nghiệm, độc lập với phần Trợ năng ở trên. Chỉ nên bật MỘT trong hai cách để tránh gọi Gemini hai lần."), 12f, MUTED).apply { setPadding(0, dp(2), 0, dp(10)) })
        sw(ct, L.tr("Bật thử nghiệm (không dùng Trợ năng)"), null, "noacc_on", false)
        run {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
            val ok = NoAccWatcher.hasUsageAccess(this)
            row.addView(label(L.tr("Quyền \"Truy cập sử dụng\": ") + (if (ok) "OK" else L.tr("CHƯA CẤP")), 13f, if (ok) INK else MUTED),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            ct.addView(row)
        }
        btn(ct, L.tr("Mở quyền Truy cập sử dụng"), top = 6) { NoAccWatcher.openUsageSettings(this); refresh() }
        seek(ct, L.tr("Khoảng hỏi lại (càng nhỏ càng nhanh, càng tốn pin)"), " ms", "noacc_poll_ms", 1000, 300)
        seek(ct, L.tr("Chờ trước khi gọi Gemini"), " ms", "noacc_delay_ms", 1000, 150)
        btn(ct, L.tr("Thử ngay (giả lập phát hiện Mi AI)"), top = 8) { NoAccWatcher.test(this) }

        val cz = card(root, L.tr("Shizuku (chạy lệnh ADB ngay trên máy)"),
            L.tr("Dùng Shizuku để tự cấp quyền cho app và chạy lệnh shell, không cần máy tính. Cần cài app Shizuku và khởi động nó trước (qua Gỡ lỗi không dây hoặc root)."))
        btn(cz, L.tr("Cấp quyền Shizuku cho app"), primary = true) {
            Toast.makeText(this, ShizukuHelper.request(), Toast.LENGTH_LONG).show()
        }
        btn(cz, L.tr("Tự cấp quyền ADB cho app qua Shizuku"), top = 8) { grantViaShizuku() }
        shzCmd = field(cz, L.tr("Lệnh shell"), "pm list packages -3", "")
        btn(cz, L.tr("Chạy lệnh"), top = 10) { runShizukuCmd(shzCmd.text.toString()) }
        shzOut = TextView(this).apply {
            textSize = 12f; setTextColor(MUTED); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            background = shape(FIELD, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        cz.addView(shzOut, lp(10))

        val c5 = card(root, L.tr("Công cụ và chẩn đoán"))
        langRow(c5)
        btn(c5, L.tr("Cài đặt pin / tự khởi động của app"), top = 14) { openAppSettings() }
        btn(c5, L.tr("Sao chép cài đặt liên quan Mi AI / nút nguồn"), top = 8) {
            copy("settings", Restorer.dumpRelated(this), L.tr("Đã sao chép – dán vào chat để gửi cho Claude"))
        }
        btn(c5, L.tr("Sao chép trạng thái"), top = 8) { copy("status", status.text, L.tr("Đã sao chép")) }
        status = TextView(this).apply {
            textSize = 12f; setTextColor(MUTED); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            background = shape(FIELD, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        c5.addView(status, lp(14))

        root.addView(label("Gemini Guard v$ver · by Đỗ Đạt - Yume. System", 12f, MUTED).apply { gravity = android.view.Gravity.CENTER },
            lp(22))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        pushService()
    }

    private fun grantViaShizuku() {
        if (!ShizukuHelper.hasPerm()) {
            Toast.makeText(this, ShizukuHelper.request(), Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, L.tr("Đang cấp quyền…"), Toast.LENGTH_SHORT).show()
        Thread {
            val res = ShizukuHelper.grantAll(this)
            runOnUiThread { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); refresh(); pushService() }
        }.start()
    }

    private fun runShizukuCmd(cmd: String) {
        if (cmd.isBlank()) return
        if (!ShizukuHelper.hasPerm()) { shzOut.text = ShizukuHelper.request(); return }
        shzOut.text = "$ $cmd\n..."
        Thread {
            val res = try { ShizukuHelper.exec(cmd) } catch (e: Throwable) { L.tr("Lỗi Shizuku: ") + e }
            runOnUiThread { shzOut.text = "$ $cmd\n$res" }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        ShizukuHelper.listen { runOnUiThread { refresh() } }
        refresh(); pushService()
    }

    override fun onPause() {
        super.onPause()
        ShizukuHelper.unlisten()
        val t = ctsPkg.text.toString().trim()
        if (t.isNotEmpty()) prefs().edit().putString("cts_pkg", t).apply()
        prefs().edit().putString("snd_cls", sndCls.text.toString().trim()).apply()
        val m = miPkgs.text.toString().trim()
        if (m.isNotEmpty()) prefs().edit().putString("mi_pkgs", m).apply()
        pushService()
    }

    private fun refresh() {
        for ((e, k) in listOf(miInc to "mi_inc", miExc to "mi_exc")) {
            val v = prefs().getString(k, if (k == "mi_inc") MiAiWatcher.DEFAULT_INC else MiAiWatcher.DEFAULT_EXC) ?: ""
            if (e.text.toString().trim() != v) e.setText(v)
        }
        val hasPerm = Restorer.hasPermission(this)
        warnCard.visibility = if (hasPerm) View.GONE else View.VISIBLE

        val r = contentResolver
        val assist = Restorer.targetAssist(this)
        val assistOk = assist != null &&
            Settings.Secure.getString(r, "assistant") == assist &&
            Settings.Secure.getString(r, "voice_interaction_service") == assist
        val pkg = prefs().getString("cts_pkg", "com.parallelc.micts") ?: ""
        val cts = packageManager.getLaunchIntentForPackage(pkg) != null

        stateBox.removeAllViews()
        stateBox.addView(stateRow(hasPerm, L.tr("Quyền ghi cài đặt bảo mật"), L.tr("Đã cấp"), L.tr("Chưa cấp")))
        stateBox.addView(stateRow(ShizukuHelper.hasPerm(), "Shizuku", L.tr("Sẵn sàng · ") + ShizukuHelper.uidText(), L.tr(ShizukuHelper.badText())))
        stateBox.addView(stateRow(assistOk, L.tr("Trợ lý mặc định"), Restorer.targetLabel(this), L.tr("Chưa đúng")))
        stateBox.addView(stateRow(Settings.canDrawOverlays(this), L.tr("Hiển thị trên ứng dụng khác"), L.tr("Đã cấp"), L.tr("Chưa cấp")))
        stateBox.addView(stateRow(Restorer.accessibilityOn(this), L.tr("Trợ năng (theo dõi Mi AI)"), L.tr("Đang bật"), L.tr("Đang tắt")))
        stateBox.addView(stateRow(cts, "MiCTS", L.tr("Đã cài"), L.tr("Chưa cài")))

        status.text = Restorer.status(this) +
            L.tr("\n\nCửa sổ Google vừa thấy (mới nhất trước):\n") +
            (prefs().getString("gseen", "")?.ifBlank { L.tr("(chưa có)") } ?: "") +
            L.tr("\n\nỨng dụng vừa thấy (để tìm tên gói Mi AI):\n") +
            (prefs().getString("seen", "")?.ifBlank { L.tr("(chưa có – bật Trợ năng rồi gọi Mi AI)") } ?: "")
    }
}
