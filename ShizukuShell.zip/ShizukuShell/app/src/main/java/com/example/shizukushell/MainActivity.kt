package com.example.shizukushell

import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private val reqCode = 1001

    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refresh() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        status = TextView(this).apply { textSize = 15f }
        val grant = Button(this).apply {
            text = "Cấp quyền Shizuku"
            setOnClickListener { requestPerm() }
        }
        input = EditText(this).apply {
            hint = "Lệnh, ví dụ: pm list packages -3"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setSingleLine(false)
        }
        val run = Button(this).apply {
            text = "Chạy"
            setOnClickListener { runCommand(input.text.toString()) }
        }
        val quick = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("id", "pm list packages -3", "dumpsys battery").forEach { c ->
            quick.addView(Button(this).apply {
                text = c.take(10); isAllCaps = false
                setOnClickListener { input.setText(c); runCommand(c) }
            })
        }
        output = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        listOf(status, grant, input, run, quick).forEach { root.addView(it) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun hasPerm() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun refresh() {
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku chưa chạy. Mở app Shizuku và khởi động nó."
            hasPerm() -> "Sẵn sàng (uid ${Shizuku.getUid()}: ${if (Shizuku.getUid() == 0) "root" else "adb/shell"})"
            else -> "Shizuku đang chạy, chưa cấp quyền."
        }
    }

    private fun requestPerm() {
        if (!Shizuku.pingBinder()) { refresh(); return }
        if (Shizuku.isPreV11()) return
        Shizuku.requestPermission(reqCode)
    }

    private fun runCommand(cmd: String) {
        if (cmd.isBlank()) return
        if (!hasPerm()) { output.text = "Chưa có quyền Shizuku."; return }
        output.text = "$ $cmd\n..."
        Thread {
            val res = try { exec(cmd) } catch (e: Throwable) { "Lỗi: $e" }
            runOnUiThread { output.text = "$ $cmd\n$res" }
        }.start()
    }

    // Shizuku.newProcess là private từ API 13, nên gọi bằng reflection.
    private fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        return "$out\n[exit $code]"
    }
}
